# app/api.py
from flask import Flask, request, jsonify
from app.database import get_playbook, insert_incident, insert_playbook

app = Flask(__name__)
@app.route('/api/incidents', methods=['POST'])
def add_incident():
    data = request.get_json()
    try:
        print(data)
        print('abcdedfdfsf')
        insert_incident(data)
        return jsonify({"message": "Incident added successfully!"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/playbooks', methods=['POST'])
def add_playbook():
    data = request.get_json()
    try:
        print(data)
        insert_playbook(data)
        return jsonify({"message": "Incident added successfully!"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/playbooks', methods=['GET'])
def get_playbooks():
    data = request.get_json()
    try:
        Selected_row = get_playbook(data['incident_id'])
        return jsonify(Selected_row), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500