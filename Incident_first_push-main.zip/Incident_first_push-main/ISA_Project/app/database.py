# app/database.py
import psycopg2
from app.config import DB_CONFIG

def get_db_connection():
    conn = psycopg2.connect(
        host=DB_CONFIG["host"],
        port=DB_CONFIG["port"],
        user=DB_CONFIG["user"],
        password=DB_CONFIG["password"],
        database=DB_CONFIG["database"]
    )
    return conn

def insert_incident(data):
    print('hello sarasree wtf')
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
    INSERT INTO incidents (type, severity, status, detected_at, resolved_at, asset_affected, playbook_id, recovery_status, description)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (
        data["type"],
        data["severity"],
        data["status"],
        data["detected_at"],
        data["resolved_at"],
        data["asset_affected"],
        data["playbook_id"],
        data["recovery_status"],
        data["description"]
    ))
    conn.commit()
    cursor.close()
    conn.close()

def insert_playbook(data):
    print('hello sarasree wtf')
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
    INSERT INTO playbooks (playbook_id, incident_id, created_at, response_steps, recovery_steps, continuity_plan, status)
    VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (
        data["playbook_id"],
        data["incident_id"],
        data["created_at"],
        data["response_steps"],
        data["recovery_steps"],
        data["continuity_plan"],
        data["status"]
    ))
    conn.commit()
    cursor.close()
    conn.close()

# This function is to get the corresponding playbook data based on the given incident ID
def get_playbook(data):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
    SELECT * FROM playbooks WHERE incident_id = %s
    """
    cursor.execute(query, (
        data,
    ))
    fetchrow_incident = cursor.fetchone()
    conn.commit()
    cursor.close()
    conn.close()
    return fetchrow_incident