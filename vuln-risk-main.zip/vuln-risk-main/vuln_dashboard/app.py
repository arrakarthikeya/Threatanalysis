from fastapi import FastAPI, HTTPException
from .models import Asset, Vulnerability, AssetWithVulnerabilities  # Use relative import
from .database import init_db, get_db_connection, generate_random_assets  # Use relative import
from .nvd_api import fetch_vulnerabilities  # Use relative import

app = FastAPI()

# Initialize database on startup
@app.on_event("startup")
def startup_event():
    init_db()
    generate_random_assets()

# Add a new asset
@app.post("/assets")
def add_asset(asset: Asset):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO assets (device_name, device_version) VALUES (?, ?)",
        (asset.device_name, asset.device_version),
    )
    conn.commit()
    return {"message": "Asset added successfully"}

# Get vulnerabilities for an asset
@app.get("/assets/{asset_id}/vulnerabilities", response_model=AssetWithVulnerabilities)
def get_vulnerabilities(asset_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Fetch asset details
    cursor.execute("SELECT * FROM assets WHERE id = ?", (asset_id,))
    asset = cursor.fetchone()

    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")

    # Fetch vulnerabilities
    vulnerabilities = fetch_vulnerabilities(
        device_name=asset["device_name"],
        device_version=asset["device_version"]
    )

    # Return asset details with vulnerabilities
    return {
        "asset_id": asset_id,
        "device_name": asset["device_name"],
        "vulnerabilities": vulnerabilities
    }

@app.get("/assets/{asset_id}/risk-score")
def get_asset_risk_score(asset_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Fetch asset details
    cursor.execute("SELECT * FROM assets WHERE id = ?", (asset_id,))
    asset = cursor.fetchone()

    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")

    # Fetch vulnerabilities
    vulnerabilities = fetch_vulnerabilities(
        device_name=asset["device_name"],
        device_version=asset["device_version"]
    )

    # Calculate average risk score
    if not vulnerabilities:
        return {"asset_id": asset_id, "average_risk_score": 0}

    total_score = sum(v.risk_score for v in vulnerabilities)
    average_score = total_score / len(vulnerabilities)

    return {"asset_id": asset_id, "average_risk_score": average_score}

@app.get("/assets", response_model=list[Asset])
def list_assets():
    """
    Retrieve all assets from the database.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    # Query to fetch all assets
    cursor.execute("SELECT id, device_name, device_version FROM assets")
    rows = cursor.fetchall()

    # Convert rows to a list of Asset objects
    assets = [
        {
            "id": row["id"],  # Include the `id` field explicitly
            "device_name": row["device_name"],
            "device_version": row["device_version"],
        }
        for row in rows
    ]

    return assets

