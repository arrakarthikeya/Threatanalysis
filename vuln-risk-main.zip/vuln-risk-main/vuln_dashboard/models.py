from pydantic import BaseModel
from typing import List

from pydantic import BaseModel

class Asset(BaseModel):
    id: int  # Add this field to represent the asset ID
    device_name: str
    device_version: str


# Model for a vulnerability
class Vulnerability(BaseModel):
    vulnerability_id: str
    risk_score: float
    description: str

# Model for an asset with its associated vulnerabilities
class AssetWithVulnerabilities(BaseModel):
    asset_id: int
    device_name: str
    vulnerabilities: List[Vulnerability]
