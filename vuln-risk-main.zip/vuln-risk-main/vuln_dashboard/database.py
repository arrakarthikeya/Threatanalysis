import sqlite3
import random

# Initialize the SQLite database
def init_db():
    conn = sqlite3.connect("vuln_dashboard.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_name TEXT NOT NULL,
            device_version TEXT NOT NULL,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

# Get a database connection
def get_db_connection():
    conn = sqlite3.connect("vuln_dashboard.db")
    conn.row_factory = sqlite3.Row
    return conn

# Generate random asset data
def generate_random_assets():
    conn = get_db_connection()
    cursor = conn.cursor()

    device_names = ["Router", "Switch", "Firewall", "Server", "Printer"]
    device_versions = ["1.0", "2.3", "3.1", "4.5", "5.6"]

    for _ in range(10):
        device_name = random.choice(device_names)
        device_version = random.choice(device_versions)
        cursor.execute(
            "INSERT INTO assets (device_name, device_version) VALUES (?, ?)",
            (device_name, device_version),
        )

    conn.commit()
    conn.close()
