import requests
from .models import Vulnerability
from .config import NVD_API_KEY

def fetch_vulnerabilities(device_name: str, device_version: str):
    """
    Fetch vulnerabilities for a given device name and version from the NVD API.
    """
    base_url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    params = {
        "keywordSearch": f"{device_name} {device_version}",
        "resultsPerPage": 10
    }
    headers = {
        "apiKey": NVD_API_KEY
    }

    print(f"[DEBUG] Fetching vulnerabilities for device: {device_name}, version: {device_version}")
    print(f"[DEBUG] API Request URL: {base_url}")
    print(f"[DEBUG] API Params: {params}")

    try:
        response = requests.get(base_url, params=params, headers=headers)
        print(f"[DEBUG] API Response Status: {response.status_code}")

        if response.status_code == 200:
            print(f"[DEBUG] API Response Body: {response.text[:500]}")  # Log the first 500 characters
            return parse_vulnerabilities(response.json())
        else:
            print(f"[ERROR] API returned status {response.status_code}: {response.text}")
            return []

    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Exception occurred while making API call: {e}")
        return []

def parse_vulnerabilities(api_response: dict):
    """
    Parse the JSON response from the NVD API into a list of Vulnerability objects.
    """
    print(f"[DEBUG] Parsing API Response")
    vulnerabilities = []
    for item in api_response.get("vulnerabilities", []):
        cve = item.get("cve", {})
        vuln_id = cve.get("id", "Unknown")
        description = cve.get("descriptions", [{}])[0].get("value", "No description available")
        risk_score = (
            item.get("metrics", {}).get("cvssMetricV31", [{}])[0]
            .get("cvssData", {}).get("baseScore", 0)
        )

        vulnerabilities.append(Vulnerability(
            vulnerability_id=vuln_id,
            risk_score=risk_score,
            description=description
        ))
    print(f"[DEBUG] Parsed {len(vulnerabilities)} vulnerabilities.")
    return vulnerabilities