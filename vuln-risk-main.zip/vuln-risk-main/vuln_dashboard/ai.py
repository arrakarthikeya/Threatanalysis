import argparse
import requests
import openai

# Configuration
BASE_URL = "http://127.0.0.1:8000"  # FastAPI server URL
OPENAI_API_KEY = "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"  # Replace with your OpenAI API key

def fetch_vulnerabilities(asset_id):
    """
    Fetch vulnerabilities for a specific asset from the FastAPI application.
    """
    url = f"{BASE_URL}/assets/{asset_id}/vulnerabilities"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error: Received status code {response.status_code} from FastAPI.")
            return None
    except Exception as e:
        print(f"Error fetching vulnerabilities: {e}")
        return None

def generate_report(vulnerability_data):
    """
    Generate a professional report using OpenAI API.
    """
    openai.api_key = OPENAI_API_KEY
    prompt = f"""
    Generate a professional vulnerability report for the following asset:

    Asset ID: {vulnerability_data['asset_id']}
    Device Name: {vulnerability_data['device_name']}
    Vulnerabilities:
    {vulnerability_data['vulnerabilities']}
    
    Summarize the vulnerabilities, their risk levels, and provide recommendations.
    """

    try:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=500,
            temperature=0.7
        )
        return response.choices[0].text.strip()
    except Exception as e:
        print(f"Error generating report: {e}")
        return None

def main(asset_id):
    """
    Main function to automate fetching vulnerabilities and generating a report.
    """
    print(f"Fetching vulnerabilities for asset ID {asset_id}...")
    vulnerabilities = fetch_vulnerabilities(asset_id)

    if not vulnerabilities:
        print("No vulnerabilities found or error in fetching data.")
        return

    print("Generating report...")
    report = generate_report(vulnerabilities)

    if report:
        print("\nGenerated Report:\n")
        print(report)
    else:
        print("Error generating the report.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate a vulnerability report for a specific asset.")
    parser.add_argument("asset_id", type=int, help="The ID of the asset to analyze")
    args = parser.parse_args()

    main(args.asset_id)
