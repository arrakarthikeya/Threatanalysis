
## Course Title
COMP-SCI 5573 - Information Security/Assurance

## Course Information
- **Instructor Name:** A S M Touhidul Hasan
- **Email:** ahrzd@umkc.edu
- **Class Times:** MoWe 4:00PM - 5:15PM
- **Location:** School of Law-Rm 3
- **Office Hours:** 
	- Tuesday: 11.00 am-12.00 pm CST  
	- Thursday: 11.00 am-12.00 pm CST
- Office: Flarsheim Hall 450P

## Tentative Course Schedule

| Weeks                                      | Topics                                                                                                           | Note                            |
| ------------------------------------------ | ---------------------------------------------------------------------------------------------------------------- | ------------------------------- |
| Week 1                                     | MODULE 1. INTRODUCTION TO INFORMATION SECURITY                                                                   | Assignment 1                    |
| Week 2                                     | MODULE 2. THE NEED FOR INFORMATION SECURITY                                                                      | Quiz 1, Assignment 2            |
| Week 3                                     | MODULE 3. INFORMATION SECURITY MANAGEMENT                                                                        | Quiz 2; Assignment 3            |
| Week 4                                     | MODULE 4. RISK MANAGEMENT                                                                                        | Quiz 3, Assignment 4, Project 1 |
| Week 5                                     | MODULE 5. INCIDENT RESPONSE AND CONTINGENCY PLANNING (Incident Response, Digital Forensics)                      | Quiz 4; Assignment 5            |
| Week 6                                     | MODULE 5. INCIDENT RESPONSE AND CONTINGENCY PLANNING (Disaster Recovery, Business Continuity, Crisis Management) | Quiz 5, Assignment 6            |
| Week 7                                     | MODULE 6. LEGAL, ETHICAL, AND PROFESSIONAL ISSUES IN INFORMATION SECURITY                                        | Quiz 6                          |
| Week 8                                     | Review and Exam 1                                                                                                | Exam 1                          |
|                                            |                                                                                                                  |                                 |
| Week 9                                     | MODULE 7. SECURITY AND PERSONNEL                                                                                 | Assignment 7                    |
| Week 10                                    | Research: Exploration of Information Security Assurance                                                          | Quiz 7, Assignment 8            |
| Week 11                                    | MODULE 8. SECURITY TECHNOLOGY: ACCESS CONTROLS, FIREWALLS, AND VPNS                                              | Project 2                       |
| Week 12                                    | MODULE 9. SECURITY TECHNOLOGY: INTRUSION DETECTION AND PREVENTION SYSTEMS AND OTHER SECURITY TOOLS               | Quiz 8, Assignment 9            |
| Week 13                                    | MODULE 10. CRYPTOGRAPHY                                                                                          | Quiz 9, Assignment 10           |
| Week 14                                    | MODULE 11. IMPLEMENTING INFORMATION SECURITY                                                                     | Quiz 10                         |
| Week 15                                    | MODULE 12. INFORMATION SECURITY MAINTENANCE                                                                      | Quiz 11, Presentation           |
| Week 16                                    | Review of Exam 2                                                                                                 | Quiz 12                         |
|                                            |                                                                                                                  |                                 |
| **Final Exam Date, Time, and Place  <br>** |                                                                                                                  |                                 |
## Important Dates & Deadlines
| Deadline   | Description           | Notes                    |
| ---------- | --------------------- | ------------------------ |
| [Enter Date] | [Assignment/Exam/Project] | [Notes or Details] |
| [Enter Date] | [Assignment/Exam/Project] | [Notes or Details] |

## Lecture Summary
| Date                 | Lecture Topic                        | Key Concepts Learned                 | Additional Notes       |
| -------------------- | ------------------------------------ | ------------------------------------ | ---------------------- |
| Monday<br>19-08-2024 | INTRODUCTION TO INFORMATION SECURITY | INTRODUCTION TO INFORMATION SECURITY | NO                     |
| [Enter Date]         | [Topic Covered]                      | [Key Concepts]                       | [Any Additional Notes] |

## To-Do List
- [x] Study ISA Module-1 📅 2024-08-21 ✅ 2024-08-23
- [x] Complete ISA Assignment-1 📅 2024-08-20 ✅ 2024-08-20
- [ ] Install, Learn and Practice Packet Tracer 📅 2024-08-26
## Miscellaneous Notes
[Add any other important information here]
