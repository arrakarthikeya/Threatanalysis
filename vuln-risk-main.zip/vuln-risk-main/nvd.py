import streamlit as st
import sqlite3
import pandas as pd
import json
from pathlib import Path
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import os

# --- Setup FastAPI ---
api_app = FastAPI()

origins = ["*"]
api_app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Database Setup ---
DB_PATH = "assets.db"
NVD_FEED_PATH = Path("nvd_feed.json")

# Initialize database
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            model TEXT,
            version TEXT
        )
        """
    )
    conn.commit()
    conn.close()

# Add asset to database
def add_asset(name, model, version):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO assets (name, model, version) VALUES (?, ?, ?)",
        (name, model, version),
    )
    conn.commit()
    conn.close()

# Delete asset from database
def delete_asset(asset_id: int):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM assets WHERE id = ?", (asset_id,))
    conn.commit()
    conn.close()

# Fetch assets from database
def get_assets():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM assets")
    rows = cursor.fetchall()
    conn.close()
    return rows

# --- Load NVD Feed ---
def load_nvd_feed(filepath):
    if filepath.exists():
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)["CVE_Items"]
    return []

# Match assets with CVEs
def match_cves(asset, cve_data):
    matched_cves = []
    for cve in cve_data:
        description = cve["cve"]["description"]["description_data"][0]["value"].lower()
        if asset[1].lower() in description or asset[2].lower() in description:
            matched_cves.append(cve["cve"]["CVE_data_meta"]["ID"])
    return matched_cves

# Generate a PDF report for an asset
def generate_pdf(asset):
    pdf_file_path = f"{asset['Asset Name'].replace(' ', '_')}_report.pdf"
    c = canvas.Canvas(pdf_file_path, pagesize=letter)
    c.setFont("Helvetica", 12)

    # Add title
    c.drawString(100, 750, f"Asset Report: {asset['Asset Name']}")

    # Add asset details
    c.drawString(100, 730, f"Model: {asset['Model']}")
    c.drawString(100, 710, f"Version: {asset['Version']}")
    c.drawString(100, 690, f"Risk Score: {asset['Risk Score']}")

    # Add CVE list
    c.drawString(100, 670, "Associated CVEs:")
    y = 650
    for cve in asset["CVEs"]:
        c.drawString(120, y, f"- {cve}")
        y -= 20

    c.save()
    return pdf_file_path

# --- Streamlit UI ---
st.title("Group 3 - Asset Risk Assessment")

init_db()
assets = get_assets()
nvd_data = load_nvd_feed(NVD_FEED_PATH)

# Add new asset
with st.form("Add New Asset"):
    st.write("Add a new asset to the database")
    name = st.text_input("Asset Name")
    model = st.text_input("Model")
    version = st.text_input("Version")
    submitted = st.form_submit_button("Add Asset")
    if submitted:
        add_asset(name, model, version)
        st.success(f"Added asset: {name} ({model}, {version})")

# Display Assets and Risk Scores
if nvd_data:
    st.write("### Asset Risk Scores")
    risk_data = []
    for asset in assets:
        matched_cves = match_cves(asset, nvd_data)
        risk_score = len(matched_cves)
        risk_data.append({
            "Asset Name": asset[1],
            "Model": asset[2],
            "Version": asset[3],
            "Risk Score": risk_score,
            "CVEs": matched_cves,
        })
    risk_df = pd.DataFrame(risk_data)
    st.dataframe(risk_df)

    # Select an asset for PDF report
    selected_asset_name = st.selectbox("Select an asset for PDF report:", [r["Asset Name"] for r in risk_data])
    selected_asset = next(r for r in risk_data if r["Asset Name"] == selected_asset_name)

    if st.button("Generate PDF Report"):
        pdf_file = generate_pdf(selected_asset)
        with open(pdf_file, "rb") as f:
            st.download_button(
                label="Download PDF Report",
                data=f,
                file_name=os.path.basename(pdf_file),
                mime="application/pdf",
            )
        os.remove(pdf_file)  # Clean up after download

# --- FastAPI Endpoints ---
@api_app.get("/assets")
def get_all_assets():
    assets = get_assets()
    if nvd_data:
        risk_data = []
        for asset in assets:
            matched_cves = match_cves(asset, nvd_data)
            risk_score = len(matched_cves)
            risk_data.append({
                "id": asset[0],
                "Asset Name": asset[1],
                "Model": asset[2],
                "Version": asset[3],
                "Risk Score": risk_score,
                "CVEs": matched_cves,
            })
        return risk_data
    return {"error": "NVD feed not loaded"}

class Asset(BaseModel):
    name: str
    model: str
    version: str

@api_app.post("/assets")
def add_new_asset(asset: Asset):
    add_asset(asset.name, asset.model, asset.version)
    return {"message": f"Added asset: {asset.name} ({asset.model}, {asset.version})"}

@api_app.delete("/assets/{asset_id}")
def delete_asset_by_id(asset_id: int):
    assets = get_assets()
    if not any(asset[0] == asset_id for asset in assets):
        raise HTTPException(status_code=404, detail="Asset not found")
    delete_asset(asset_id)
    return {"message": f"Asset with ID {asset_id} deleted successfully"}

# Run API in parallel
def run_api():
    uvicorn.run(api_app, host="0.0.0.0", port=8000)

st.sidebar.title("API Status")
if st.sidebar.button("Start API"):
    st.sidebar.success("API is running on port 8000.")
    run_api()