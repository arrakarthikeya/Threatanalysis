﻿# real_time_threat_intelligence

This is the main repository for the REAL TIME THREAT INTELLIGENCE PLATFORM project which includes the below modules as branches: 

Module 1: Asset Management

Module 2: Threat Intelligence Aggregation

Module 3: Vulnerability and Risk Assessment

Module 4: Incident Response, Disaster Recovery, and Business Continuity

Module 5: Crisis Management

Module 6: Centralized Dashboard
